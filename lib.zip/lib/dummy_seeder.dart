import 'package:cloud_firestore/cloud_firestore.dart';

class DummySeeder {
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;

  static Future<void> seedAll() async {
    // =====================================================
    // USERS
    // =====================================================

    final users = [
      {
        'uid': 'creator_jawa',
        'nama': 'Chef Jawa',
        'email': 'jawa@test.com',
        'foto_profil':
            'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
        'bio': 'Masakan khas Jawa autentik',
        'lokasi': 'Yogyakarta',
        'instagram': '@chefjawa',
        'youtube': '',
        'website': '',
        'created_at': Timestamp.now(),
      },

      {
        'uid': 'creator_sumatera',
        'nama': 'Dapur Sumatera',
        'email': 'sumatera@test.com',
        'foto_profil':
            'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
        'bio': 'Kuliner khas Sumatera',
        'lokasi': 'Padang',
        'instagram': '@dapursumatera',
        'youtube': '',
        'website': '',
        'created_at': Timestamp.now(),
      },

      {
        'uid': 'creator_bali',
        'nama': 'Bali Culinary',
        'email': 'bali@test.com',
        'foto_profil':
            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
        'bio': 'Masakan khas Bali',
        'lokasi': 'Denpasar',
        'instagram': '@baliculinary',
        'youtube': '',
        'website': '',
        'created_at': Timestamp.now(),
      },

      {
        'uid': 'creator_sulawesi',
        'nama': 'Sulawesi Food',
        'email': 'sulawesi@test.com',
        'foto_profil':
            'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d',
        'bio': 'Kuliner Sulawesi',
        'lokasi': 'Makassar',
        'instagram': '@sulawesifood',
        'youtube': '',
        'website': '',
        'created_at': Timestamp.now(),
      },

      {
        'uid': 'creator_papua',
        'nama': 'Papua Kitchen',
        'email': 'papua@test.com',
        'foto_profil':
            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
        'bio': 'Kuliner Papua',
        'lokasi': 'Jayapura',
        'instagram': '@papuakitchen',
        'youtube': '',
        'website': '',
        'created_at': Timestamp.now(),
      },
    ];

    // SAVE USERS

    for (var user in users) {
      await firestore.collection('users').doc(user['uid'] as String).set(user);
    }

    // =====================================================
    // RECIPES
    // =====================================================

    final recipes = [
     {
  'nama_resep': 'Soto Lamongan',
  'foto_cover': 'assets/images/recipes/soto_lamongan.jpg',
  'provinsi': 'Jawa Timur',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '45 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.7,
  'jumlah_review': 15,
  'jumlah_favorit': 80,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Ayam',
    'Kunyit',
    'Soun',
  ],

  'langkah': [
    'Rebus ayam',
    'Tumis bumbu',
    'Sajikan dengan soun',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Pecel Madiun',
  'foto_cover': 'assets/images/recipes/pecel_madiun.jpg',
  'provinsi': 'Jawa Timur',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '30 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.5,
  'jumlah_review': 12,
  'jumlah_favorit': 60,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Sayuran',
    'Sambal kacang',
    'Lontong',
  ],

  'langkah': [
    'Rebus sayur',
    'Siapkan sambal',
    'Sajikan',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Batagor Bandung',
  'foto_cover': 'assets/images/recipes/batagor.jpg',
  'provinsi': 'Jawa Barat',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.6,
  'jumlah_review': 16,
  'jumlah_favorit': 70,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Tahu',
    'Ikan tenggiri',
    'Saus kacang',
  ],

  'langkah': [
    'Isi tahu',
    'Goreng',
    'Siram saus kacang',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Lumpia Semarang',
  'foto_cover': 'assets/images/recipes/lumpia.jpg',
  'provinsi': 'Jawa Tengah',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '50 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.7,
  'jumlah_review': 18,
  'jumlah_favorit': 75,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Rebung',
    'Kulit lumpia',
    'Ayam',
  ],

  'langkah': [
    'Tumis isian',
    'Bungkus lumpia',
    'Goreng hingga matang',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Rujak Cingur',
  'foto_cover': 'assets/images/recipes/rujak_cingur.jpg',
  'provinsi': 'Jawa Timur',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.4,
  'jumlah_review': 11,
  'jumlah_favorit': 55,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Cingur',
    'Sayuran',
    'Petis',
  ],

  'langkah': [
    'Rebus cingur',
    'Siapkan bumbu petis',
    'Campurkan semua bahan',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Nasi Liwet Solo',
  'foto_cover': 'assets/images/recipes/nasi_liwet.jpg',
  'provinsi': 'Jawa Tengah',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.5,
  'jumlah_review': 10,
  'jumlah_favorit': 50,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Nasi',
    'Ayam suwir',
    'Santan',
  ],

  'langkah': [
    'Masak nasi santan',
    'Siapkan ayam',
    'Sajikan',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Tahu Gimbal',
  'foto_cover': 'assets/images/recipes/tahu_gimbal.jpg',
  'provinsi': 'Jawa Tengah',
  'kategori_provinsi': 'Jawa',
  'waktu_masak': '30 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 40,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Tahu',
    'Udang',
    'Kol',
  ],

  'langkah': [
    'Goreng tahu',
    'Buat bakwan udang',
    'Siram saus kacang',
  ],

  'author_uid': 'creator_jawa',
  'created_at': Timestamp.now(),
},

      {
  'nama_resep': 'Sate Padang',
  'foto_cover': 'assets/images/recipes/sate_padang.jpg',
  'provinsi': 'Sumatera Barat',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '50 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.8,
  'jumlah_review': 22,
  'jumlah_favorit': 90,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Daging sapi',
    'Tepung beras',
    'Cabai',
  ],

  'langkah': [
    'Rebus daging',
    'Buat kuah sate',
    'Bakar sate',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Mie Aceh',
  'foto_cover': 'assets/images/recipes/mie_aceh.jpg',
  'provinsi': 'Aceh',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.7,
  'jumlah_review': 18,
  'jumlah_favorit': 75,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Mie kuning',
    'Udang',
    'Cabai',
  ],

  'langkah': [
    'Tumis bumbu',
    'Masukkan mie',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Bika Ambon',
  'foto_cover': 'assets/images/recipes/bika_ambon.jpg',
  'provinsi': 'Sumatera Utara',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '60 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.5,
  'jumlah_review': 12,
  'jumlah_favorit': 55,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Tepung tapioka',
    'Telur',
    'Santan',
  ],

  'langkah': [
    'Campur bahan',
    'Diamkan adonan',
    'Panggang',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Gulai Ikan Patin',
  'foto_cover': 'assets/images/recipes/gulai_patin.jpg',
  'provinsi': 'Jambi',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '45 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.6,
  'jumlah_review': 14,
  'jumlah_favorit': 60,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan patin',
    'Santan',
    'Kunyit',
  ],

  'langkah': [
    'Tumis bumbu',
    'Masukkan ikan',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Tekwan Palembang',
  'foto_cover': 'assets/images/recipes/tekwan.jpg',
  'provinsi': 'Sumatera Selatan',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.5,
  'jumlah_review': 10,
  'jumlah_favorit': 50,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan tenggiri',
    'Jamur kuping',
    'Soun',
  ],

  'langkah': [
    'Bentuk adonan ikan',
    'Rebus tekwan',
    'Sajikan dengan kuah',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Lempah Kuning',
  'foto_cover': 'assets/images/recipes/lempah_kuning.jpg',
  'provinsi': 'Bangka Belitung',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 45,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan kakap',
    'Kunyit',
    'Cabai',
  ],

  'langkah': [
    'Rebus ikan',
    'Masukkan bumbu',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Pendap Bengkulu',
  'foto_cover': 'assets/images/recipes/pendap.jpg',
  'provinsi': 'Bengkulu',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '70 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.3,
  'jumlah_review': 8,
  'jumlah_favorit': 40,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan laut',
    'Kelapa parut',
    'Daun talas',
  ],

  'langkah': [
    'Lumuri ikan',
    'Bungkus daun talas',
    'Kukus hingga matang',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Gulai Belacan',
  'foto_cover': 'assets/images/recipes/gulai_belacan.jpg',
  'provinsi': 'Riau',
  'kategori_provinsi': 'Sumatera',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 42,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Udang',
    'Belacan',
    'Santan',
  ],

  'langkah': [
    'Tumis bumbu',
    'Masukkan udang',
    'Masak kuah santan',
  ],

  'author_uid': 'creator_sumatera',
  'created_at': Timestamp.now(),
},

      // =================================================
      // BALI
      // =================================================
      {
  'nama_resep': 'Lawar Bali',
  'foto_cover': 'assets/images/recipes/lawar_bali.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.6,
  'jumlah_review': 15,
  'jumlah_favorit': 65,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Kelapa parut',
    'Daging ayam',
    'Kacang panjang',
  ],

  'langkah': [
    'Rebus sayuran',
    'Campur kelapa dan bumbu',
    'Sajikan',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Nasi Campur Bali',
  'foto_cover': 'assets/images/recipes/nasi_campur_bali.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.7,
  'jumlah_review': 20,
  'jumlah_favorit': 85,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Nasi putih',
    'Ayam suwir',
    'Sambal matah',
  ],

  'langkah': [
    'Siapkan lauk',
    'Tata di atas nasi',
    'Sajikan',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Sambal Matah',
  'foto_cover': 'assets/images/recipes/sambal_matah.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '15 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.5,
  'jumlah_review': 14,
  'jumlah_favorit': 55,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Bawang merah',
    'Cabai rawit',
    'Minyak kelapa',
  ],

  'langkah': [
    'Iris semua bahan',
    'Campur dengan minyak panas',
    'Sajikan',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Tum Ayam Bali',
  'foto_cover': 'assets/images/recipes/tum_ayam.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '45 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.6,
  'jumlah_review': 12,
  'jumlah_favorit': 50,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Daging ayam cincang',
    'Kelapa',
    'Daun pisang',
  ],

  'langkah': [
    'Campur bahan',
    'Bungkus daun pisang',
    'Kukus hingga matang',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Serombotan',
  'foto_cover': 'assets/images/recipes/serombotan.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '25 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.3,
  'jumlah_review': 8,
  'jumlah_favorit': 40,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Kangkung',
    'Tauge',
    'Sambal kelapa',
  ],

  'langkah': [
    'Rebus sayur',
    'Siapkan sambal',
    'Campurkan',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Tipat Cantok',
  'foto_cover': 'assets/images/recipes/tipat_cantok.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '20 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 42,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ketupat',
    'Sayuran',
    'Saus kacang',
  ],

  'langkah': [
    'Potong ketupat',
    'Rebus sayur',
    'Siram saus kacang',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Be Genyol',
  'foto_cover': 'assets/images/recipes/be_genyol.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '90 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.5,
  'jumlah_review': 10,
  'jumlah_favorit': 48,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Daging babi',
    'Bumbu bali',
    'Cabai',
  ],

  'langkah': [
    'Lumuri daging',
    'Masak perlahan',
    'Sajikan hangat',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Jukut Ares',
  'foto_cover': 'assets/images/recipes/jukut_ares.jpg',
  'provinsi': 'Bali',
  'kategori_provinsi': 'Bali',
  'waktu_masak': '50 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.3,
  'jumlah_review': 7,
  'jumlah_favorit': 35,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Batang pisang muda',
    'Ayam',
    'Santan',
  ],

  'langkah': [
    'Iris batang pisang',
    'Masak dengan santan',
    'Tambahkan ayam',
  ],

  'author_uid': 'creator_bali',
  'created_at': Timestamp.now(),
},
{
  'nama_resep': 'Coto Makassar',
  'foto_cover': 'assets/images/recipes/coto_makassar.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '60 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.8,
  'jumlah_review': 20,
  'jumlah_favorit': 85,
  'is_popular': true,
  'is_featured': true,

  'bahan': [
    'Daging sapi',
    'Kacang tanah',
    'Serai',
  ],

  'langkah': [
    'Rebus daging',
    'Haluskan bumbu',
    'Masak kuah hingga matang',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Pallubasa',
  'foto_cover': 'assets/images/recipes/pallubasa.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '55 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.6,
  'jumlah_review': 15,
  'jumlah_favorit': 70,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Daging sapi',
    'Kelapa sangrai',
    'Bawang putih',
  ],

  'langkah': [
    'Rebus daging',
    'Masukkan bumbu',
    'Sajikan hangat',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Konro Bakar',
  'foto_cover': 'assets/images/recipes/konro_bakar.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '90 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.7,
  'jumlah_review': 18,
  'jumlah_favorit': 80,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Iga sapi',
    'Ketumbar',
    'Kecap',
  ],

  'langkah': [
    'Rebus iga',
    'Lumuri bumbu',
    'Bakar hingga matang',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Tinutuan',
  'foto_cover': 'assets/images/recipes/tinutuan.jpg',
  'provinsi': 'Sulawesi Utara',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 10,
  'jumlah_favorit': 45,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Labu',
    'Bayam',
    'Jagung',
  ],

  'langkah': [
    'Rebus sayuran',
    'Masukkan jagung',
    'Masak hingga lembut',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Ikan Woku',
  'foto_cover': 'assets/images/recipes/ikan_woku.jpg',
  'provinsi': 'Sulawesi Utara',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.7,
  'jumlah_review': 14,
  'jumlah_favorit': 60,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Ikan tongkol',
    'Daun kemangi',
    'Cabai',
  ],

  'langkah': [
    'Tumis bumbu',
    'Masukkan ikan',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Kapurung',
  'foto_cover': 'assets/images/recipes/kapurung.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '45 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.5,
  'jumlah_review': 11,
  'jumlah_favorit': 50,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Sagu',
    'Ikan',
    'Sayuran',
  ],

  'langkah': [
    'Seduh sagu',
    'Masak ikan',
    'Campurkan semua bahan',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Barongko',
  'foto_cover': 'assets/images/recipes/barongko.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '30 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.3,
  'jumlah_review': 8,
  'jumlah_favorit': 35,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Pisang',
    'Telur',
    'Santan',
  ],

  'langkah': [
    'Haluskan pisang',
    'Campur bahan',
    'Kukus hingga matang',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Binte Biluhuta',
  'foto_cover': 'assets/images/recipes/binte_biluhuta.jpg',
  'provinsi': 'Gorontalo',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '25 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 40,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Jagung',
    'Udang',
    'Kelapa parut',
  ],

  'langkah': [
    'Rebus jagung',
    'Masukkan udang',
    'Tambahkan kelapa',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Gogos',
  'foto_cover': 'assets/images/recipes/gogos.jpg',
  'provinsi': 'Sulawesi Selatan',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '20 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.2,
  'jumlah_review': 7,
  'jumlah_favorit': 30,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Beras ketan',
    'Santan',
    'Daun pisang',
  ],

  'langkah': [
    'Masak ketan',
    'Bungkus daun pisang',
    'Bakar sebentar',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Paniki',
  'foto_cover': 'assets/images/recipes/paniki.jpg',
  'provinsi': 'Sulawesi Utara',
  'kategori_provinsi': 'Sulawesi',
  'waktu_masak': '70 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.1,
  'jumlah_review': 6,
  'jumlah_favorit': 28,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Daging kelelawar',
    'Cabai',
    'Santan',
  ],

  'langkah': [
    'Bersihkan daging',
    'Masak dengan bumbu',
    'Tambahkan santan',
  ],

  'author_uid': 'creator_sulawesi',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Papeda',
  'foto_cover': 'assets/images/recipes/papeda.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '20 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.5,
  'jumlah_review': 12,
  'jumlah_favorit': 50,
  'is_popular': true,
  'is_featured': true,

  'bahan': [
    'Sagu',
    'Air panas',
    'Ikan kuah kuning',
  ],

  'langkah': [
    'Larutkan sagu',
    'Seduh air panas',
    'Sajikan dengan ikan',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Ikan Kuah Kuning',
  'foto_cover': 'assets/images/recipes/ikan_kuah_kuning.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.6,
  'jumlah_review': 10,
  'jumlah_favorit': 45,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Ikan tongkol',
    'Kunyit',
    'Serai',
  ],

  'langkah': [
    'Tumis bumbu',
    'Masukkan ikan',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Udang Selingkuh',
  'foto_cover': 'assets/images/recipes/udang_selingkuh.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '40 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.7,
  'jumlah_review': 14,
  'jumlah_favorit': 60,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Udang air tawar',
    'Bawang putih',
    'Cabai',
  ],

  'langkah': [
    'Bersihkan udang',
    'Tumis bumbu',
    'Masak hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Sagu Lempeng',
  'foto_cover': 'assets/images/recipes/sagu_lempeng.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '25 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.2,
  'jumlah_review': 8,
  'jumlah_favorit': 35,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Tepung sagu',
    'Air',
    'Garam',
  ],

  'langkah': [
    'Campur bahan',
    'Cetak adonan',
    'Panggang hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Aunu Senebre',
  'foto_cover': 'assets/images/recipes/aunu_senebre.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '30 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.3,
  'jumlah_review': 7,
  'jumlah_favorit': 32,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan teri',
    'Daun talas',
    'Kelapa parut',
  ],

  'langkah': [
    'Kukus daun talas',
    'Campur bahan',
    'Sajikan hangat',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Kue Lontar',
  'foto_cover': 'assets/images/recipes/kue_lontar.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '50 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.5,
  'jumlah_review': 11,
  'jumlah_favorit': 48,
  'is_popular': true,
  'is_featured': false,

  'bahan': [
    'Tepung terigu',
    'Susu',
    'Telur',
  ],

  'langkah': [
    'Buat adonan',
    'Tuang ke loyang',
    'Panggang hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Ikan Bungkus',
  'foto_cover': 'assets/images/recipes/ikan_bungkus.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '45 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.4,
  'jumlah_review': 9,
  'jumlah_favorit': 40,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ikan nila',
    'Daun pisang',
    'Cabai',
  ],

  'langkah': [
    'Lumuri ikan',
    'Bungkus daun pisang',
    'Bakar hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Sate Ulat Sagu',
  'foto_cover': 'assets/images/recipes/sate_ulat_sagu.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '20 Menit',
  'tingkat_kesulitan': 'Sulit',
  'rating': 4.0,
  'jumlah_review': 5,
  'jumlah_favorit': 25,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ulat sagu',
    'Garam',
    'Jeruk nipis',
  ],

  'langkah': [
    'Bersihkan ulat sagu',
    'Tusuk seperti sate',
    'Bakar hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Petatas',
  'foto_cover': 'assets/images/recipes/petatas.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '25 Menit',
  'tingkat_kesulitan': 'Mudah',
  'rating': 4.1,
  'jumlah_review': 6,
  'jumlah_favorit': 28,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Ubi jalar',
    'Garam',
    'Kelapa',
  ],

  'langkah': [
    'Kupas ubi',
    'Rebus hingga empuk',
    'Sajikan',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

{
  'nama_resep': 'Martabak Sagu',
  'foto_cover': 'assets/images/recipes/martabak_sagu.jpg',
  'provinsi': 'Papua',
  'kategori_provinsi': 'Papua',
  'waktu_masak': '35 Menit',
  'tingkat_kesulitan': 'Menengah',
  'rating': 4.2,
  'jumlah_review': 7,
  'jumlah_favorit': 30,
  'is_popular': false,
  'is_featured': false,

  'bahan': [
    'Tepung sagu',
    'Telur',
    'Daun bawang',
  ],

  'langkah': [
    'Campur adonan',
    'Masak di teflon',
    'Balik hingga matang',
  ],

  'author_uid': 'creator_papua',
  'created_at': Timestamp.now(),
},

    ];

    // SAVE RECIPES

    for (var recipe in recipes) {
      await firestore.collection('resep').add(recipe);
    }

    print('DUMMY DATA BERHASIL DIBUAT');
  }
}
