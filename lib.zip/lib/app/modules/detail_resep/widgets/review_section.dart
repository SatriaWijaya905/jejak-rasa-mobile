import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import '../../../services/notification_service.dart';

String _timeAgo(DateTime d) {
  Duration diff = DateTime.now().difference(d);
  if (diff.inDays > 365) return '${(diff.inDays / 365).floor()} tahun yang lalu';
  if (diff.inDays > 30) return '${(diff.inDays / 30).floor()} bulan yang lalu';
  if (diff.inDays > 7) return '${(diff.inDays / 7).floor()} minggu yang lalu';
  if (diff.inDays > 0) return '${diff.inDays} hari yang lalu';
  if (diff.inHours > 0) return '${diff.inHours} jam yang lalu';
  if (diff.inMinutes > 0) return '${diff.inMinutes} menit yang lalu';
  return 'Baru saja';
}

class _RatingPicker extends StatelessWidget {
  final double rating;
  final ValueChanged<double> onChanged;

  const _RatingPicker({required this.rating, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(5, (index) {
        final starValue = index + 1;
        return IconButton(
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          onPressed: () => onChanged(starValue.toDouble()),
          icon: Icon(
            starValue <= rating ? Icons.star_rounded : Icons.star_outline_rounded,
            color: const Color(0xFFF5A623),
            size: 28,
          ),
        );
      }),
    );
  }
}

class _ReviewActions extends StatelessWidget {
  final bool isOwner;
  final String resepId;
  final String reviewId;
  final String initialKomentar;
  final double initialRating;

  const _ReviewActions({
    required this.isOwner,
    required this.resepId,
    required this.reviewId,
    required this.initialKomentar,
    required this.initialRating,
  });

  @override
  Widget build(BuildContext context) {
    if (!isOwner) return const SizedBox.shrink();

    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_horiz, size: 20, color: Colors.grey),
      padding: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      onSelected: (value) async {
        if (value == 'edit') {
          final komentarController = TextEditingController(text: initialKomentar);
          double ratingTmp = initialRating;

          await Get.dialog(
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Text('Edit Review', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _RatingPicker(
                      rating: ratingTmp,
                      onChanged: (v) {
                        ratingTmp = v;
                        (context as Element).markNeedsBuild();
                      },
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: komentarController,
                      maxLines: 3,
                      style: GoogleFonts.poppins(fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Tulis komentar...',
                        hintStyle: GoogleFonts.poppins(color: Colors.grey.shade400),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: Color(0xFFF5A623), width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Get.back(),
                  child: Text('Batal', style: GoogleFonts.poppins(color: Colors.grey)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF5A623),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () async {
                    final newKomentar = komentarController.text.trim();
                    if (newKomentar.isEmpty) {
                      Get.snackbar(
                        'Komentar kosong',
                        'Komentar tidak boleh kosong',
                        snackPosition: SnackPosition.BOTTOM,
                        backgroundColor: Colors.red,
                        colorText: Colors.white,
                        margin: const EdgeInsets.all(12),
                        borderRadius: 16,
                      );
                      return;
                    }

                    await FirebaseFirestore.instance
                        .collection('resep')
                        .doc(resepId)
                        .collection('reviews')
                        .doc(reviewId)
                        .update({'komentar': newKomentar, 'rating': ratingTmp});

                    final snap = await FirebaseFirestore.instance
                        .collection('resep')
                        .doc(resepId)
                        .collection('reviews')
                        .get();

                    double total = 0;
                    for (var d in snap.docs) {
                      total += (d.data()['rating'] ?? 0).toDouble();
                    }
                    final avg = snap.docs.isEmpty ? 0 : total / snap.docs.length;

                    await FirebaseFirestore.instance
                        .collection('resep')
                        .doc(resepId)
                        .update({'rating': avg, 'jumlah_review': snap.docs.length});

                    Get.back();
                  },
                  child: Text('Simpan', style: GoogleFonts.poppins(color: Colors.white)),
                ),
              ],
            ),
          );
        }

        if (value == 'delete') {
          final ok = await Get.dialog<bool>(
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              title: Text('Hapus Review', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
              content: Text('Yakin ingin menghapus review ini?', style: GoogleFonts.poppins()),
              actions: [
                TextButton(
                  onPressed: () => Get.back(result: false),
                  child: Text('Batal', style: GoogleFonts.poppins(color: Colors.grey)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Get.back(result: true),
                  child: Text('Hapus', style: GoogleFonts.poppins(color: Colors.white)),
                ),
              ],
            ),
          );

          if (ok != true) return;

          await FirebaseFirestore.instance
              .collection('resep')
              .doc(resepId)
              .collection('reviews')
              .doc(reviewId)
              .delete();

          final snap = await FirebaseFirestore.instance
              .collection('resep')
              .doc(resepId)
              .collection('reviews')
              .get();

          double total = 0;
          for (var d in snap.docs) {
            total += (d.data()['rating'] ?? 0).toDouble();
          }
          final avg = snap.docs.isEmpty ? 0 : total / snap.docs.length;

          await FirebaseFirestore.instance
              .collection('resep')
              .doc(resepId)
              .update({'rating': avg, 'jumlah_review': snap.docs.length});
        }
      },
      itemBuilder: (_) => [
        PopupMenuItem(
          value: 'edit',
          child: Row(
            children: [
              const Icon(Icons.edit_rounded, size: 18),
              const SizedBox(width: 8),
              Text('Edit', style: GoogleFonts.poppins()),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'delete',
          child: Row(
            children: [
              const Icon(Icons.delete_rounded, size: 18, color: Colors.red),
              const SizedBox(width: 8),
              Text('Hapus', style: GoogleFonts.poppins(color: Colors.red)),
            ],
          ),
        ),
      ],
    );
  }
}

class ReviewSection extends StatefulWidget {
  final String resepId;

  const ReviewSection({super.key, required this.resepId});

  @override
  State<ReviewSection> createState() => _ReviewSectionState();
}

class _ReviewSectionState extends State<ReviewSection> {
  final komentarC = TextEditingController();
  double rating = 5;
  bool isLoadingSubmit = false;

  static const Color _accent = Color(0xFFF5A623);
  static const Color _cream = Color(0xFFFFF8EE);

  Future<void> submitReview() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        Get.snackbar(
          'Perlu login',
          'Silakan login untuk memberi review',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          margin: const EdgeInsets.all(12),
          borderRadius: 16,
        );
        return;
      }

      final komentar = komentarC.text.trim();
      if (komentar.isEmpty) {
        Get.snackbar(
          'Komentar kosong',
          'Komentar tidak boleh kosong',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          margin: const EdgeInsets.all(12),
          borderRadius: 16,
        );
        return;
      }

      setState(() => isLoadingSubmit = true);

      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final userData = userDoc.data() ?? {};

      final reviewDocRef = await FirebaseFirestore.instance
          .collection('resep')
          .doc(widget.resepId)
          .collection('reviews')
          .add({
        'uid': user.uid,
        'nama_user': userData['nama'] ?? 'User',
        'foto_user': userData['foto_profil'] ?? '',
        'komentar': komentar,
        'rating': rating,
        'created_at': DateTime.now(),
      });

      final resepDoc = await FirebaseFirestore.instance.collection('resep').doc(widget.resepId).get();
      final resepData = resepDoc.data() as Map<String, dynamic>?;
      final ownerUid = (resepData?['author_uid'] as String?) ?? '';
      final recipeName = (resepData?['nama_resep'] as String?) ?? 'Resep';

      final reviewSnapshot = await FirebaseFirestore.instance
          .collection('resep')
          .doc(widget.resepId)
          .collection('reviews')
          .get();

      double total = 0;
      for (var doc in reviewSnapshot.docs) {
        total += (doc.data()['rating'] ?? 0).toDouble();
      }
      double average = reviewSnapshot.docs.isEmpty ? 0 : total / reviewSnapshot.docs.length;

      await FirebaseFirestore.instance.collection('resep').doc(widget.resepId).update({
        'rating': average,
        'jumlah_review': reviewSnapshot.docs.length,
      });

      final notifId = reviewDocRef.id;
      if (ownerUid.trim().isNotEmpty && user.uid.trim().isNotEmpty) {
        await NotificationService.sendCommentRecipeNotification(
          recipeOwnerUid: ownerUid,
          senderUid: user.uid,
          senderName: userData['nama'] ?? 'Pengguna',
          senderPhoto: userData['foto_profil'] ?? '',
          recipeId: widget.resepId,
          recipeName: recipeName,
          notifId: notifId,
        );
      }

      komentarC.clear();
      setState(() => rating = 5);
      FocusScope.of(context).unfocus();

      Get.snackbar(
        'Berhasil',
        'Review berhasil ditambahkan',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        borderRadius: 16,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        borderRadius: 16,
      );
    } finally {
      setState(() => isLoadingSubmit = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance.collection('resep').doc(widget.resepId).snapshots(),
            builder: (context, snapshot) {
              double avg = 0;
              int totalReview = 0;
              if (snapshot.hasData && snapshot.data!.data() != null) {
                final data = snapshot.data!.data() as Map<String, dynamic>;
                avg = (data['rating'] ?? 0).toDouble();
                totalReview = data['jumlah_review'] ?? 0;
              }
              return Row(
                children: [
                  const Icon(Icons.star_rounded, color: _accent, size: 28),
                  const SizedBox(width: 8),
                  Text(
                    '${avg.toStringAsFixed(1)} ',
                    style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black87),
                  ),
                  Text(
                    '($totalReview ulasan)',
                    style: GoogleFonts.poppins(fontSize: 14, color: Colors.grey.shade600, fontWeight: FontWeight.w500),
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 24),
          
          // Form Review
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Beri Penilaian',
                  style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.black87),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(5, (index) {
                    return IconButton(
                      padding: const EdgeInsets.only(right: 4),
                      constraints: const BoxConstraints(),
                      onPressed: () => setState(() => rating = (index + 1).toDouble()),
                      icon: Icon(
                        index < rating ? Icons.star_rounded : Icons.star_outline_rounded,
                        color: _accent,
                        size: 32,
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: komentarC,
                  maxLines: 3,
                  style: GoogleFonts.poppins(fontSize: 14, color: Colors.black87),
                  decoration: InputDecoration(
                    hintText: 'Bagaimana hasil resep ini menurutmu?',
                    hintStyle: GoogleFonts.poppins(color: Colors.grey.shade400, fontSize: 13),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.all(16),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: _accent, width: 2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [_accent, Color(0xFFFF8C00)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: _accent.withOpacity(0.3),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                      ),
                      onPressed: isLoadingSubmit ? null : submitReview,
                      child: isLoadingSubmit
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                            )
                          : Text(
                              'Kirim Review',
                              style: GoogleFonts.poppins(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Text(
            'Ulasan Pengguna',
            style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
          ),
          const SizedBox(height: 16),
          
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('resep')
                .doc(widget.resepId)
                .collection('reviews')
                .orderBy('created_at', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: CircularProgressIndicator(color: _accent),
                ));
              }

              final docs = snapshot.data!.docs;
              if (docs.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Icon(Icons.chat_bubble_outline_rounded, size: 48, color: Colors.grey.shade300),
                        const SizedBox(height: 12),
                        Text(
                          'Jadilah yang pertama mengulas resep ini!',
                          style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey.shade500),
                        ),
                      ],
                    ),
                  ),
                );
              }

              final currentUid = FirebaseAuth.instance.currentUser?.uid;

              return ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: docs.length,
                separatorBuilder: (context, index) => const SizedBox(height: 16),
                itemBuilder: (context, index) {
                  final doc = docs[index];
                  final data = doc.data() as Map<String, dynamic>;
                  final isOwner = currentUid != null && data['uid'] == currentUid;
                  
                  // Format time
                  String timeText = '';
                  if (data['created_at'] != null) {
                    final timestamp = data['created_at'] as Timestamp;
                    final date = timestamp.toDate();
                    timeText = _timeAgo(date);
                  }

                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8F9FA),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.grey.shade100),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.05),
                                    blurRadius: 5,
                                  ),
                                ],
                              ),
                              child: CircleAvatar(
                                radius: 20,
                                backgroundColor: _cream,
                                backgroundImage: (data['foto_user'] != null && data['foto_user'] != '')
                                    ? NetworkImage(data['foto_user'])
                                    : null,
                                child: (data['foto_user'] == null || data['foto_user'] == '')
                                    ? const Icon(Icons.person_rounded, color: _accent, size: 20)
                                    : null,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    data['nama_user'] ?? 'Pengguna',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Row(
                                        children: List.generate(
                                          (data['rating'] ?? 0).toInt(),
                                          (index) => const Icon(Icons.star_rounded, size: 14, color: _accent),
                                        ),
                                      ),
                                      if (timeText.isNotEmpty) ...[
                                        const SizedBox(width: 8),
                                        Container(width: 4, height: 4, decoration: BoxDecoration(color: Colors.grey.shade400, shape: BoxShape.circle)),
                                        const SizedBox(width: 8),
                                        Text(
                                          timeText,
                                          style: GoogleFonts.poppins(fontSize: 11, color: Colors.grey.shade500),
                                        ),
                                      ]
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            _ReviewActions(
                              isOwner: isOwner,
                              resepId: widget.resepId,
                              reviewId: doc.id,
                              initialKomentar: data['komentar'] ?? '',
                              initialRating: (data['rating'] ?? 0).toDouble(),
                            ),
                          ],
                        ),
                        if (data['komentar'] != null && data['komentar'].toString().isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 12, left: 52),
                            child: Text(
                              data['komentar'],
                              style: GoogleFonts.poppins(
                                fontSize: 13,
                                color: Colors.black87,
                                height: 1.5,
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
