import 'package:get/get.dart';

class KategoriProvinsiController
    extends GetxController {

  final kategori = [

    'Jawa',

    'Sumatera',

    'Bali',

    'Sulawesi',

    'Papua',
  ];
}